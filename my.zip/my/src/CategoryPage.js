import React from 'react';
import { useParams } from 'react-router-dom';
import './CategoryPage.css';

const CategoryPage = () => {
  const { category } = useParams();
  const subCategories = ['지성', '건성', '복합성'];
  const productsName ={
    "skin-지성": "라포슈포제 에빠끌라 토너",
    "skin-건성": "라포슈포제 에빠끌라 토너",
    "skin-복합성": "라포슈포제 에빠끌라 토너",
    "lotion-지성": "바이오더마 세비엄 로션",
    "lotion-건성": "크리니크 라이징 로션",
    "lotion-복합성": "유세린 수분크림",
    "body-지성": "스카이보틀 바디로션",
    "body-건성": "바세린 바디로션",
    "body-복합성": "칼앤한스 바디로션",
  }


  return (
    <div className="category-page">
      <h1 className="category-title">{category}</h1>
      <div className="sub-categories">
        {subCategories.map((sub, index) => (
          <div key={sub} className="sub-category">
            <h2 className="sub-title">{sub}</h2>
            <div className="product">
              <img src={`/${category}-${sub}.png`} alt="제품이미지" className="product-image" />
              <p className="product-name">
                {productsName[`${category}-${sub}`]}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CategoryPage;
