import React from 'react';
import { Link } from 'react-router-dom';
import './MainPage.css';

const MainPage = () => {
  return (
    <div className="main-page">
      <div className="header">
        <h1>KIM'S SKIN</h1>
      </div>
      <div className="categories">
        <div className="category">
          <Link to="/category/skin" className="color-block skin"></Link>
          <p className="category-label">스킨</p>
        </div>
        <div className="category">
          <Link to="/category/lotion" className="color-block lotion"></Link>
          <p className="category-label">로션</p>
        </div>
        <div className="category">
          <Link to="/category/body" className="color-block body"></Link>
          <p className="category-label">바디</p>
        </div>
        <div className="category">
          <Link to="/test" className="color-block diagnosis"></Link>
          <p className="category-label">피부진단</p>
        </div>
      </div>
      <p className="tagline">“추구하는 가치”</p>
    </div>
  );
};

export default MainPage;
