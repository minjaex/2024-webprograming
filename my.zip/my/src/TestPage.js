import React, { useState } from 'react';
import './TestPage.css';
import { useNavigate } from 'react-router-dom';

const TestPage = () => {
  const navigate = useNavigate();
  const [answers, setAnswers] = useState({});
  const questions = [
    "세안 후 피부 당김이 있으십니까?",
    "피부 색소침착이 있으십니까?",
    "표정변화가 있을 때 주름이 많이 생기십니까?",
  ];

  const handleAnswerChange = (index, answer) => {
    setAnswers({
      ...answers,
      [index]: answer,
    });
  };

  const calculateResult = () => {
    const yesCount = Object.values(answers).filter(answer => answer === 'yes').length;
    if (yesCount >= 2) {
      return "지성";
    } else {
      return "건성";
    }
  };

  return (
    <div className="test-page">
      <h1 className="test-title">피부진단 자가테스트</h1>
      <div className="questions">
        {questions.map((question, index) => (
          <div key={index} className="question">
            <p>{question}</p>
            <button onClick={() => handleAnswerChange(index, 'yes')}>YES</button>
            <button onClick={() => handleAnswerChange(index, 'no')}>NO</button>
          </div>
        ))}
      </div>
      <div className="result">
        <p>당신의 피부 타입은 "{calculateResult()}" 입니다.</p>
        <button onClick={()=>navigate("/category/lotion")}>추천 제품 보러가기</button>
      </div>
    </div>
  );
};

export default TestPage;
